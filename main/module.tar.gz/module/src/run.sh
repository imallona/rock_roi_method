
python -m main.combined_rock_roi
